SOURCES += \
        animation/qguivariantanimation.cpp
